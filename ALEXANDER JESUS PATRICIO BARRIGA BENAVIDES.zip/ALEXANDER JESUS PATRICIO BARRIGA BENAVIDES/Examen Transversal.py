peliculas = {'P101': ['Luz de Otoño', 'drama', 110, 'B', 'Español', False],
                'P102': ['Noche Neón', 'acción', 125, 'C', 'Ingles', True],
                'P103': ['Planeta Agua', 'documental', 90, 'A', 'Español',
                False],
                'P104': ['Risa Total', 'comedia', 105, 'A', 'Español', True],
                'P105': ['Código Zero', 'thriller', 118, 'C', 'Ingles', True],
                'P106': ['Viaje Lunar', 'ciencia ficción', 132, 'B', 'Ingles',
                False]}
cartelera = {'P101': [5990, 40],
                'P102': [7990, 0],
                'P103': [4990, 25],
                'P104': [6990, 12],
                'P105': [8990, 8],
                'P106': [7490, 3]}


def cupos_genero(genero):
    cant = 0
    for codigo in peliculas:
        gen = peliculas[codigo][1]
        if gen.lower() == genero.lower():
            cant += cartelera[codigo][1]
    print("Cupos del genero:", cant)



def busqueda_precio(p_min, p_max):
    l = []
    for codigo in cartelera:
        precio, cantidad = cartelera[codigo]
        if p_min <= precio <= p_max and cantidad > 0:
            peli = peliculas[codigo][0]
            l.append(peli + "--" + codigo)
    l.sort()
    if len(l) != 0:
        print("Peliculas en ese rango de precio: ", l)
    else:
        print("No hay peliculas en ese rango de precios.")


def actualizar_precio(codigo, nuevo_precio):

    if codigo in cartelera:
        p_actual, cant = cartelera[codigo]
        cartelera[codigo] = [nuevo_precio, cant]
        return True
    else:
        return False
    
def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d,precio, cupos):
    if codigo == "":
        return False
    if codigo not in peliculas[codigo]:
        return False
    if titulo == "":
        return False
    if genero == "":
        return False
    if duracion <= 0:
        return False
    if clasificacion == "A" or clasificacion == "B" or clasificacion == "C":
        return True
    if idioma == "":
        return False
    if es_3d == "n" or "no":
        return False
    if precio <= 0: 
        return False
    if cupos <= 0:
        return False
    else:
        return True

def eliminar_pelicula(codigo):
    if codigo in peliculas:
        del(peliculas[codigo])

def buscar_codigo(codigo):
    if codigo in peliculas:
        return True
    else:
        return False


    






while True:

    print("=== MENU PRINCIPAL ===")
    print("1.- Cupos por genero")
    print("2.- Busqueda de pelicula por rango de precio")
    print("3.- Actualizar precio de pelicula")
    print("4.- Agregar pelicula")
    print("5.- Eliminar pelicula")
    print("6.- Salir")
    opcion = int(input("Ingrese una opcion: "))
    if opcion == 1:
        genero = input("Ingrese el genero a buscar: ")
        cupos_genero(genero)
    elif opcion == 2:
        try:
            p_min = int(input("Ingrese un precio minimo: "))
            p_max = int(input("Ingrese un precio maximo: "))
            busqueda_precio(p_min, p_max)
        except:
            print("Debe ingresar valores enteros")
    elif opcion == 3:
        while True:
            codigo = input("Ingrese código a actualizar: ")
            buscar_codigo(codigo)
            try:
                nuevo_precio = int(input("Ingrese precio nuevo: "))
            except:
                print("Debe ingresar un valor entero!!")
                continue
            resp = actualizar_precio(codigo, nuevo_precio)
            if resp:
                print("Precio actualizado!!")
            else:
                print("El código no existe!!")
            r = input("Desea actualizar otro (s/n)?: ")
            if r == "no" or r == "n":
                break
    elif opcion == 4:
        while True:
            codigo = input("Ingrese código a actualizar: ")
            titulo = input("Ingrese titulo de la pelicula: ")
            genero = input("Ingrese genero de la pelicula")
            try:
                duracion = int(input("Ingrese la duracion de la pelicula: "))
            except:
                print("Debe ingresar un valor entero")
                continue
            clasificacion = input("Ingrese la clasificacion de la pelicula").upper
            idioma = input("Ingrese el idioma de la pelicula")
            es_3d = input("La pelicula es 3D? (s/n): ").lower
            try:
                precio = int(input("Ingrese el precio de la pelicula"))
            except:
                print("Debe ingresar un valor entero")
                continue
            try:
                cupos = int(input("Ingrese los cupos de la pelicula"))
            except:
                print("Debe ingresar un valor entero")
                continue
            resp = agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d,precio, cupos)
            if resp:
                print("Pelicula agregada exitosamente!")
            else:
                print("La pelicula no se ha agregado correctamente.")
    elif opcion == 5:
        codigo = input("Ingresa el codigo de la pelicula: ")
        resp = buscar_codigo(codigo)
        if resp:
            eliminar_pelicula(codigo)
            print("Pelicula eliminada")
        else:
            print("El codigo no existe")
    elif opcion == 6:
        print("Programa finalizado.")
        break